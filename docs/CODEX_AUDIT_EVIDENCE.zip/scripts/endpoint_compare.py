exec(open('/workspace/work/audit/contracts.py').read().split('# Every network invocation')[0])
from django.urls import resolve,Resolver404
front=Path('/workspace/AestheticWay');config=(front/'lib/core/network/api_config.dart').read_text();constants={};dynamic={}
for name,value in re.findall(r"static const String (\w+)\s*=\s*'([^']+)';",config):constants[name]=value
for name,alias in re.findall(r'static const String (\w+)\s*=\s*(\w+);',config):
 if alias in constants:constants[name]=constants[alias]
for name,value in re.findall(r"static String (\w+)\([^)]*\)\s*=>\s*'([^']+)';",config):dynamic[name]=value
calls=json.loads((out/'frontend_network_calls.json').read_text());rows=[]
u='11111111-1111-4111-8111-111111111111'
for c in calls:
 args=c['arguments'];m=re.search(r'ApiConfig\.(\w+)',args)
 if m:
  name=m.group(1);path=constants.get(name) or dynamic.get(name)
 else:
  name='endpoint';path={'leads_repository.dart':'leads/'+u+'/', 'clinics_repository.dart':'clinics/'+u+'/', 'offers_repository.dart':'offers/'+u+'/'}[Path(c['file']).name]
 if not path:
  c.update(result='UNRESOLVED');rows.append(c);continue
 path=re.sub(r'\$\w+',u,path);url='/api/v1/'+path
 try:
  match=resolve(url);cls=match.func.cls;action=(getattr(match.func,'actions',None) or {}).get(c['method'].lower());supported=bool(action) if hasattr(match.func,'actions') else hasattr(cls,c['method'].lower())
  c.update(endpoint=url,backend=cls.__module__+'.'+cls.__name__,action=action,result='METHOD_OK' if supported else 'METHOD_MISMATCH')
 except Resolver404:c.update(endpoint=url,result='NO_ROUTE')
 rows.append(c)
(out/'endpoint_comparison.json').write_text(json.dumps(rows,indent=2));print('Callsites',len(rows))
from collections import Counter
print(Counter(x['result'] for x in rows))
for c in rows:
 if c['result']!='METHOD_OK':print(c)
