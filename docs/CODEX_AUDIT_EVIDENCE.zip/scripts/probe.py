import os,sys,io,json,tempfile
from unittest.mock import patch
from pathlib import Path
sys.path.insert(0,'/workspace/work/audit/backend')
os.environ.update(DJANGO_SETTINGS_MODULE='config.settings.testing',SECRET_KEY='audit-only-test-key-not-for-production',USE_R2_STORAGE='False',USE_S3='False',PYTHONDONTWRITEBYTECODE='1')
import django
django.setup()
from django.core.management import call_command
from django.test import override_settings
from django.core.files.uploadedfile import SimpleUploadedFile
from django.urls import resolve, Resolver404
from PIL import Image
from rest_framework.test import APIClient
from apps.accounts.models import User,ClinicUser
from apps.clinics.models import Clinic
from apps.practitioners.models import Practitioner
from apps.products.models import Product
from apps.articles.models import Article
from apps.offers.models import Offer
from apps.treatments.models import Category,Treatment,PractitionerTreatment
from apps.media.models import MediaAsset
from apps.leads.models import Lead
from django.utils import timezone
from datetime import timedelta
call_command('migrate',verbosity=0)
results=[]
def record(check_name,**kwargs):
 results.append({'check':check_name,**kwargs});print(json.dumps(results[-1],default=str,ensure_ascii=False))
def img(mime='image/png',name='probe.png'):
 b=io.BytesIO();Image.new('RGB',(8,8),'red').save(b,format='PNG');return SimpleUploadedFile(name,b.getvalue(),content_type=mime)
with override_settings(ALLOWED_HOSTS=['testserver'],MEDIA_ROOT=tempfile.mkdtemp(prefix='aw_audit_probe_'),STORAGES={'default':{'BACKEND':'django.core.files.storage.FileSystemStorage'},'staticfiles':{'BACKEND':'django.contrib.staticfiles.storage.StaticFilesStorage'}}):
 clinic=Clinic.objects.create(name_en='Audit Clinic',slug='audit',status='active')
 other=Clinic.objects.create(name_en='Other Clinic',slug='other',status='active')
 user=User.objects.create_user(phone='+971501234567',password='StrongAuditPass!42',full_name='Audit Admin',role='clinic_admin',is_verified=True)
 ClinicUser.objects.create(user=user,clinic=clinic,role_in_clinic='admin',is_active=True)
 client=APIClient();client.force_authenticate(user=user)
 for mime in ['application/octet-stream','image/png']:
  res=client.post('/api/v1/media/upload/',{'file':img(mime),'media_type':'practitioner_avatar'},format='multipart')
  record('media_upload_mime',mime=mime,status=res.status_code,data=res.data)
  if res.status_code==201:asset_id=res.data['id']
 res=client.patch('/api/v1/clinic-portal/profile/',{'name_en':'Saved Clinic','logo':img('application/octet-stream')},format='multipart')
 clinic.refresh_from_db();record('clinic_profile_binary',status=res.status_code,logo=res.data.get('logo'),persisted=bool(clinic.logo),exists=clinic.logo.storage.exists(clinic.logo.name))
 old=clinic.logo.name
 res=client.patch('/api/v1/clinic-portal/profile/',{'name_en':'Saved Again','logo':'/tmp/new.png'},format='json')
 clinic.refresh_from_db();record('clinic_profile_string',status=res.status_code,unchanged=clinic.logo.name==old,name=clinic.name_en)
 res=client.patch('/api/v1/clinic-portal/profile/',{'logo':None},format='json');clinic.refresh_from_db();record('clinic_profile_clear_json_null',status=res.status_code,cleared=not bool(clinic.logo))
 practitioner=Practitioner.objects.create(clinic=clinic,name_en='Old Photo',avatar='https://example.org/old.png')
 res=client.patch(f'/api/v1/clinic-portal/practitioners/{practitioner.id}/',{'avatar':'https://example.org/new.png','media_asset':asset_id},format='json')
 practitioner.refresh_from_db();record('practitioner_stale_avatar',status=res.status_code,asset_persisted=str(practitioner.media_asset_id)==asset_id,returned_avatar_url=res.data.get('avatar_url'))
 foreign=MediaAsset.objects.create(media_type='product_image',file=img(),file_size=80,mime_type='image/png',original_filename='probe.png',clinic=other)
 for kind,obj,payload in [('practitioners',practitioner,{'media_asset':str(foreign.id)}),('products',Product.objects.create(clinic=clinic,name_en='Product'),{'media_asset':str(foreign.id)}),('articles',Article.objects.create(clinic=clinic,title_en='Article',slug='audit-article'),{'media_asset':str(foreign.id)}),('offers',Offer.objects.create(clinic=clinic,title_en='Offer',original_price=10,offer_price=9,starts_at=timezone.now()-timedelta(days=1),ends_at=timezone.now()+timedelta(days=1)),{'media_asset':str(foreign.id)})]:
  res=client.patch(f'/api/v1/clinic-portal/{kind}/{obj.id}/',payload,format='json');record('foreign_media_asset',entity=kind,status=res.status_code)
 category=Category.objects.create(name_en='Skin',slug='skin')
 res=client.post('/api/v1/clinic-portal/treatments/',{'name_en':'Missing Category'},format='json');record('treatment_missing_category',status=res.status_code,data=res.data)
 treatment=Treatment.objects.create(clinic=clinic,category=category,name_en='Existing Treatment')
 PractitionerTreatment.objects.create(practitioner=practitioner,treatment=treatment)
 res=client.patch(f'/api/v1/clinic-portal/treatments/{treatment.id}/',{'name_en':'Renamed','practitioners':[]},format='json');record('treatment_empty_assignments',status=res.status_code,remaining=treatment.practitioners.count())
 lead=Lead.objects.create(clinic=clinic,patient_name='Patient',patient_phone='+971501234568',consent_accepted=True)
 res=client.patch(f'/api/v1/clinic-portal/leads/{lead.id}/',{'status':'closed'},format='json');record('lead_status_patch_shape',status=res.status_code,data=res.data)
 res=client.patch('/api/v1/auth/me/',{'phone':'+971501234569','email':'new@example.org','full_name':'Changed'},format='json');user.refresh_from_db();record('me_read_only_contact',status=res.status_code,phone=user.phone,email=user.email,name=user.full_name)
 admin=User.objects.create_user(phone='+971501234570',password='StrongAuditPass!42',full_name='Super',role='super_admin',is_verified=True)
 client.force_authenticate(user=admin)
 base={'name_en':'Provisioned','admin_user':{'full_name':'New Admin','phone':'+971501234571','temporary_password':'StrongAuditPass!42'}}
 res=client.post('/api/v1/admin/clinics/',{**base,'logo':'https://example.org/a.png','google_maps_url':'https://maps.google.com/test'},format='json')
 if res.status_code==201:
  made=Clinic.objects.get(pk=res.data['clinic']['id']);record('provision_ignored_media_maps',status=res.status_code,logo=bool(made.logo),google_maps_url=made.google_maps_url)
 flat={'name_en':'Multipart Provision','admin_user[full_name]':'New Admin 2','admin_user[phone]':'+971501234572','logo':img()}
 res=client.post('/api/v1/admin/clinics/',flat,format='multipart');record('provision_bracket_multipart',status=res.status_code,data=res.data)
 client.force_authenticate(user=user)
 for url in [f'/api/v1/clinics/{clinic.id}/reviews/','/invite/token/','/r/token/']:
  try:record('url_resolution',url=url,view=resolve(url).func.__name__)
  except Resolver404:record('url_resolution',url=url,status='NO_ROUTE')
 # A suspended clinic still has active memberships; lead portal ignores clinic status.
 clinic.status='suspended';clinic.save(update_fields=['status'])
 res=client.get('/api/v1/clinic-portal/leads/');record('suspended_clinic_lead_access',status=res.status_code)
 from django.core.cache import cache
 from apps.accounts.services.otp import _otp_key,hash_otp
 import time
 cache.clear()
 patient=User.objects.create_user(phone='+971501234573',password='StrongAuditPass!42',email='audit@example.org',full_name='Unverified',role='patient',is_verified=False)
 anon=APIClient()
 res=anon.post('/api/v1/auth/login/',{'identifier':patient.phone,'password':'StrongAuditPass!42'},format='json')
 record('unverified_login',status=res.status_code,access_token_issued=bool(res.data.get('access_token')))
 cache.set(_otp_key(patient.phone,'password_reset'),f"{hash_otp('123456')}|{int(time.time())+300}",timeout=300)
 res=anon.post('/api/v1/auth/verify-otp/',{'phone':patient.phone,'otp_code':'123456','purpose':'password_reset'},format='json')
 record('reset_step_verify',status=res.status_code)
 res=anon.post('/api/v1/auth/reset-password/',{'phone':patient.phone,'otp_code':'123456','new_password':'DifferentStrongPass!74'},format='json')
 record('reset_step_save_after_verify',status=res.status_code,data=res.data)
 clinic.status='active';clinic.save(update_fields=['status'])
 product=Product.objects.filter(clinic=clinic).first()
 res=anon.post('/api/v1/leads/',{'clinic':str(clinic.id),'product':str(product.id),'lead_type':'product','patient_name':'Audit Patient','patient_phone':'+971501234574','consent_accepted':True},format='json')
 record('product_inquiry_enum',status=res.status_code,data=res.data)
Path('/workspace/work/audit/evidence/probes.json').write_text(json.dumps(results,indent=2,default=str,ensure_ascii=False))
