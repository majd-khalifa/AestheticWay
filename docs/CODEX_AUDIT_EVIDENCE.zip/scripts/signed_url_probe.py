import os,sys,json
from urllib.parse import urlsplit,urlunsplit,parse_qs
sys.path.insert(0,'/workspace/work/audit/backend')
os.environ.update(DJANGO_SETTINGS_MODULE='config.settings.testing',SECRET_KEY='audit-only-test-key-not-for-production',USE_R2_STORAGE='False',USE_S3='False')
import django
django.setup()
import boto3
from botocore.config import Config
from botocore.credentials import Credentials
from botocore.auth import S3SigV4QueryAuth
from botocore.awsrequest import AWSRequest
from apps.products.portal_serializers import ClinicProductPortalSerializer
from apps.articles.portal_serializers import ClinicArticlePortalSerializer
client=boto3.client('s3',endpoint_url='https://audit.r2.cloudflarestorage.com',region_name='auto',aws_access_key_id='AUDIT_FAKE_KEY',aws_secret_access_key='audit-fake-secret',config=Config(signature_version='s3v4'))
url=client.generate_presigned_url('get_object',Params={'Bucket':'audit','Key':'media_assets/clinics/a0f38478-6e7b-4121-99d2-72a2997fe2bc/product_image/2026/10/example.png'},ExpiresIn=3600)
parts=urlsplit(url);original_sig=parse_qs(parts.query)['X-Amz-Signature'][0]
base_query='&'.join(x for x in parts.query.split('&') if not x.startswith('X-Amz-Signature='))
base=urlunsplit(parts._replace(query=base_query))
signer=S3SigV4QueryAuth(Credentials('AUDIT_FAKE_KEY','audit-fake-secret'),'s3','auto',expires=3600)
def signature(u):
 req=AWSRequest(method='GET',url=u);req.context['timestamp']=parse_qs(parts.query)['X-Amz-Date'][0]
 canonical=signer.canonical_request(req);return signer.signature(signer.string_to_sign(req,canonical),req)
result={'url_length':len(url),'unmodified_signature_valid':signature(base)==original_sig,'signature_valid_after_flutter_v_parameter':signature(base+'&v=123456')==original_sig}
for cls,key in [(ClinicProductPortalSerializer,'image'),(ClinicArticlePortalSerializer,'cover_image')]:
 try:cls().fields[key].run_validation(url);result[cls.__name__]='accepted'
 except Exception as exc:result[cls.__name__]=str(exc)
print(json.dumps(result,indent=2));open('/workspace/work/audit/evidence/signed-url.json','w').write(json.dumps(result,indent=2))
