import os,sys,importlib,inspect,json,re
from pathlib import Path
sys.path.insert(0,'/workspace/work/audit/backend')
os.environ.update(DJANGO_SETTINGS_MODULE='config.settings.testing',SECRET_KEY='audit-only-test-key-not-for-production',USE_R2_STORAGE='False',USE_S3='False')
import django
django.setup()
from django.urls import get_resolver,URLResolver
from rest_framework.serializers import BaseSerializer
root=Path('/workspace/work/audit/backend');out=Path('/workspace/work/audit/evidence');schemas={};routes=[]
for p in list(root.glob('apps/**/serializers.py'))+list(root.glob('apps/**/portal_serializers.py')):
 mod=importlib.import_module(str(p.relative_to(root).with_suffix('')).replace('/','.'))
 for n,cls in inspect.getmembers(mod,inspect.isclass):
  if cls.__module__!=mod.__name__ or not issubclass(cls,BaseSerializer):continue
  try:
   obj=cls();schemas[cls.__module__+'.'+n]={key:dict(type=type(f).__name__,required=f.required,read_only=f.read_only,allow_null=f.allow_null,source=f.source) for key,f in obj.fields.items()}
  except Exception as e:schemas[cls.__module__+'.'+n]={'ERROR':str(e)}
def walk(patterns,prefix=''):
 for p in patterns:
  path=prefix+str(p.pattern)
  if isinstance(p,URLResolver):walk(p.url_patterns,path)
  else:
   cls=getattr(p.callback,'cls',None) or getattr(p.callback,'view_class',None)
   if not cls:continue
   actions=getattr(p.callback,'actions',None)
   methods=list(actions) if actions else [x for x in ['get','post','patch','put','delete'] if hasattr(cls,x)]
   routes.append(dict(path=path,view=cls.__module__+'.'+cls.__name__,methods=methods,actions=actions))
walk(get_resolver().url_patterns)
(out/'serializer_contracts.json').write_text(json.dumps(schemas,indent=2));(out/'routes.json').write_text(json.dumps(routes,indent=2))
print('Serializer classes',len(schemas),'Routes',len(routes))
# Every network invocation, excluding method declarations on the client itself.
calls=[];front=Path('/workspace/AestheticWay')
for p in sorted((front/'lib').rglob('*.dart')):
 if p.name=='api_client.dart':continue
 s=p.read_text()
 for m in re.finditer(r'\b(?:_apiClient|_api|_client|_dio|refreshDio)\.(get|post|patch|put|delete)(?:<[^>]+>)?\(',s):
  begin=m.end();depth=1;quote=None;escape=False;i=begin
  while i<len(s) and depth:
   c=s[i]
   if quote:
    if escape:escape=False
    elif c=='\\':escape=True
    elif c==quote:quote=None
   elif c in ['"',"'"]:quote=c
   elif c=='(':depth+=1
   elif c==')':depth-=1
   i+=1
  body=s[begin:i-1];calls.append(dict(file=str(p.relative_to(front)),line=s.count('\n',0,m.start())+1,method=m.group(1).upper(),arguments=body.strip()))
(out/'frontend_network_calls.json').write_text(json.dumps(calls,indent=2))
for c in calls:print(c['file']+':'+str(c['line']),c['method'],c['arguments'].split('\n')[0])
